// application
import { IProduct } from '../../interfaces/product';

export interface CompareState {
    items: IProduct[];
}
