export interface MobileMenuState {
    open: boolean;
}
