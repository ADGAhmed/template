export interface LocaleState {
    current: string;
}
