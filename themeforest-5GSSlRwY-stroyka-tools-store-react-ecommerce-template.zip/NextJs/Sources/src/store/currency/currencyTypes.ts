import { ICurrency } from '../../interfaces/currency';

export interface CurrencyState {
    current: ICurrency;
}
