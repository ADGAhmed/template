const version = 1;

export default version;
