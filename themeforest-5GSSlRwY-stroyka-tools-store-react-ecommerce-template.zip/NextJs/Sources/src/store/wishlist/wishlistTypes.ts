// application
import { IProduct } from '../../interfaces/product';

export interface WishlistState {
    items: IProduct[];
}
