export interface ICurrency {
    code: string;
    symbol: string;
    name: string;
}
