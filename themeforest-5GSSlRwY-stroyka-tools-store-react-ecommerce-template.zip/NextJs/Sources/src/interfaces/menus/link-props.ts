import { LinkProps } from 'next/link';

export interface ILinkProps extends LinkProps {
    href: string;
}
