export interface IPayment {
    key: string;
    title: string;
    description: string;
}
