// application
import BlogPagePost from '../../components/blog/BlogPagePost';

function Page() {
    return <BlogPagePost layout="full" />;
}

export default Page;
