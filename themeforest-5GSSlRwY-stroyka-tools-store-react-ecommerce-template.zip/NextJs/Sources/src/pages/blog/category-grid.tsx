// application
import BlogPageCategory from '../../components/blog/BlogPageCategory';

function Page() {
    return <BlogPageCategory layout="grid" sidebarPosition="end" />;
}

export default Page;
