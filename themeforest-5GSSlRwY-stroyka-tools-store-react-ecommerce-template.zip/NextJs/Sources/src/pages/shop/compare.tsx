// application
import ShopPageCompare from '../../components/shop/ShopPageCompare';

function Page() {
    return <ShopPageCompare />;
}

export default Page;
