import Page from './[slug]';

export { getServerSideProps } from './[slug]';
export default Page;
