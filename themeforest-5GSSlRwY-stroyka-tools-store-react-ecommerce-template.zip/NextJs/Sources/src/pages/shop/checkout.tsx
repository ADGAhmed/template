// application
import ShopPageCheckout from '../../components/shop/ShopPageCheckout';

function Page() {
    return <ShopPageCheckout />;
}

export default Page;
