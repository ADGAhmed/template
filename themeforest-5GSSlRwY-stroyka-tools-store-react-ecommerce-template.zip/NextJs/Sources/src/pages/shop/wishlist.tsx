// application
import ShopPageWishlist from '../../components/shop/ShopPageWishlist';

function Page() {
    return <ShopPageWishlist />;
}

export default Page;
