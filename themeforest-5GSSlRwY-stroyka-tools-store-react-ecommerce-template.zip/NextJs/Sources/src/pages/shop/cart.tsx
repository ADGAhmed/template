// application
import ShopPageCart from '../../components/shop/ShopPageCart';

function Page() {
    return <ShopPageCart />;
}

export default Page;
