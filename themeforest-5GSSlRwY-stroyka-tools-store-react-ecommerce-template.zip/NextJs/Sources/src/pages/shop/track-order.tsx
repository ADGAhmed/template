// application
import ShopPageTrackOrder from '../../components/shop/ShopPageTrackOrder';

function Page() {
    return <ShopPageTrackOrder />;
}

export default Page;
