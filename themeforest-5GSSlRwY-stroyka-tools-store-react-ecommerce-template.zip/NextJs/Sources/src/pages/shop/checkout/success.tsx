// application
import ShopPageOrderSuccess from '../../../components/shop/ShopPageOrderSuccess';

function Page() {
    return <ShopPageOrderSuccess />;
}

export default Page;
