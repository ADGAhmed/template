// application
import AccountPageLogin from '../../components/account/AccountPageLogin';

function Page() {
    return <AccountPageLogin />;
}

export default Page;
