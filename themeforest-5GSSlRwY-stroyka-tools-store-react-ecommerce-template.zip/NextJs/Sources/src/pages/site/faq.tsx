// application
import SitePageFaq from '../../components/site/SitePageFaq';

function Page() {
    return <SitePageFaq />;
}

export default Page;
