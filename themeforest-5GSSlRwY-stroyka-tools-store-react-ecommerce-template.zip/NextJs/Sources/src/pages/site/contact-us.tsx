// application
import SitePageContactUs from '../../components/site/SitePageContactUs';

function Page() {
    return <SitePageContactUs />;
}

export default Page;
