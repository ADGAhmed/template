// application
import SitePageContactUsAlt from '../../components/site/SitePageContactUsAlt';

function Page() {
    return <SitePageContactUsAlt />;
}

export default Page;
