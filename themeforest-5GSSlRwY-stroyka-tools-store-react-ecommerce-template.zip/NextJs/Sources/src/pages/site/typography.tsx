// application
import SitePageTypography from '../../components/site/SitePageTypography';

function Page() {
    return <SitePageTypography />;
}

export default Page;
