// application
import SitePageTerms from '../../components/site/SitePageTerms';

function Page() {
    return <SitePageTerms />;
}

export default Page;
