// application
import SitePageAboutUs from '../../components/site/SitePageAboutUs';

function Page() {
    return <SitePageAboutUs />;
}

export default Page;
