// application
import SitePageComponents from '../../components/site/SitePageComponents';

function Page() {
    return <SitePageComponents />;
}

export default Page;
