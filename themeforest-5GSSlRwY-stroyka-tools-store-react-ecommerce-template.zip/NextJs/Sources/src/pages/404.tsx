// application
import SitePageNotFound from '../components/site/SitePageNotFound';

function Page() {
    return <SitePageNotFound />;
}

export default Page;
