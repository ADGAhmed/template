export interface IBrandDef {
    slug: string;
    name: string;
    image: string;
}
